// import { app } from "./app";
// import config from "./config";

// app.listen(config.port, function () {
//   console.log(`Started on http://localhost:${config.port}`);
// });
